1. I have completed all parts of the program

2. There are no issues I am aware of

3. I have included a make file and compilation can be handled by using make clean &&m make all
   I have included a few runnable options for the make file
   make run0graph1
   make run0graph2
   make run1graph1
   make run1graph2
   make run2five
   make run2ten
   make run2twenty
   make run2fifty
   make run2hundred
   make run2thousand
   make run2hundredthousand

4. The input files are Graph1.txt, Graph2.txt, AdjacencyQueries1.txt, and AdjancencyQueries2.txt
   There are no output files


